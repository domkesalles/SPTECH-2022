public class DVD extends Produto{
    private String gravadora;

    public DVD(Integer codigo, Double precoCusto, String nome, String gravadora) {
        super(codigo, precoCusto, nome);
        this.gravadora = gravadora;
    }

    public String getGravadora() {
        return gravadora;
    }

    public void setGravadora(String gravadora) {
        this.gravadora = gravadora;
    }

    @Override
    public Double getValorVenda() {
        return getPrecoCusto() * 1.2;
    }

    @Override
    public String toString() {
        return "DVD{" +
                "gravadora='" + gravadora + '\'' +
                "valor de venda='" + getValorVenda() + '\'' +
                "} " + super.toString();
    }
}
