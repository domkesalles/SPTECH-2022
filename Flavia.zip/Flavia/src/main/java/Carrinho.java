import java.util.ArrayList;
import java.util.List;

public class Carrinho {
    List<Vendavel> cart;

    public Carrinho() {
        cart = new ArrayList<>();
    }

    public void adicionaVenda(Vendavel v) {
        cart.add(v);
    }

    public Double calculaTotalVenda() {
        Double total = 0.0;
        for (Vendavel vendavel : cart) {
            total += vendavel.getValorVenda();
        }
        System.out.println(total);
        return total;
    }

    public void exibeItensCarrinho() {
        for (Vendavel vendavel : cart) {
            System.out.println(vendavel);
        }
    }
}
