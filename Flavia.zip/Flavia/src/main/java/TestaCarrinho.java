import java.util.Scanner;

public class TestaCarrinho {
    public static void main(String[] args) {
        Carrinho carrinho = new Carrinho();

        Scanner leitor1 = new Scanner(System.in);
        Scanner leitorNL = new Scanner(System.in);
        int leitor;

        do {
            System.out.println("1. Adicionar livro\n" +
                    "2. Adicionar DVD\n" +
                    "3. Adicionar serviço\n" +
                    "4. Exibir itens do carrinho\n" +
                    "5. Exibir total de venda\n" +
                    "6. Fim\n");
            leitor = new Scanner(System.in).nextInt();

            switch (leitor) {
                case 1:
                    System.out.println("\nDigite o código: ");
                    Integer codigo = leitor1.nextInt();

                    System.out.println("\nDigite o nome: ");
                    String nome = leitorNL.nextLine();

                    System.out.println("\nDigite o preço custo: ");
                    Double precoCusto = leitor1.nextDouble();

                    System.out.println("\nDigite o autor: ");
                    String autor = leitorNL.nextLine();

                    System.out.println("\nDigite o ISBN: ");
                    String isbn = leitorNL.nextLine();

                    Livro livro = new Livro(codigo, precoCusto, nome, autor, isbn);
                    carrinho.adicionaVenda(livro);

                case 2:
                    System.out.println("\nDigite o código: ");
                    Integer codigoDVD = leitor1.nextInt();

                    System.out.println("\nDigite o nome: ");
                    String nomeDVD = leitorNL.nextLine();

                    System.out.println("\nDigite o preço custo: ");
                    Double precoCustoDVD = leitor1.nextDouble();

                    System.out.println("\nDigite a gravadora: ");
                    String gravadora = leitorNL.nextLine();

                    DVD dvd = new DVD(codigoDVD, precoCustoDVD, nomeDVD, gravadora);
                    carrinho.adicionaVenda(dvd);

                case 3:
                    System.out.println("\nDigite a descrição do serviço: ");
                    String descricao = leitorNL.nextLine();

                    System.out.println("\nDigite o código: ");
                    Integer codigoServico = leitor1.nextInt();

                    System.out.println("\nDigite a quantidade de horas: ");
                    Integer qtdeHoras = leitor1.nextInt();

                    System.out.println("\nDigite o valor da hora: ");
                    Double valorHoras = leitor1.nextDouble();

                    Servico servico = new Servico(descricao, codigoServico, qtdeHoras, valorHoras);
                    carrinho.adicionaVenda(servico);

                case 4:
                    carrinho.exibeItensCarrinho();

                case 5:
                    carrinho.calculaTotalVenda();

                case 6:
                default:
            }
        } while (leitor != 6);
    }
}
