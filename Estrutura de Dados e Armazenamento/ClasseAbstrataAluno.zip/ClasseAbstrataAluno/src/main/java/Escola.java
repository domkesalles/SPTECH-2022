import java.util.ArrayList;
import java.util.List;

public class Escola {
    private String nome;
    private List<Aluno> alunos;

    public Escola(String nome) {
        this.nome = nome;
        alunos = new ArrayList<>();
    }

    public void adicionarAluno(Aluno aluno) {
        alunos.add(aluno);
    }

    public void exibeTodos() {
        for (Aluno aluno : alunos) {
            System.out.println(aluno);
        }
    }

    public void exibeAlunoGraduacao() {
        for (Aluno aluno : alunos) {
            if (aluno instanceof AlunoGraduacao) {
                System.out.println(aluno);
            }
        }
    }

    public void exibeAprovados() {
        for (Aluno aluno : alunos) {
            if (aluno.calcularMedia() > 6.0) {
                System.out.println(aluno);
            }
        }
    }

    public void buscarAluno(Integer ra) {
        System.out.println("\nRA do aluno desejado: " + ra);
        for (Aluno aluno : alunos) {
            if (aluno.getRa() == ra) {
                System.out.println(aluno);
                return;
            }
        }
        System.out.println("\nAluno não encontrado");
    }
}
