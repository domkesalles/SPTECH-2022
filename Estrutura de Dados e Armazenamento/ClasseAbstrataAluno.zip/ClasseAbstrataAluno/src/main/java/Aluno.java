abstract public class Aluno {
    private Integer ra;
    private String nome;

    public Aluno(Integer ra, String nome) {
        this.ra = ra;
        this.nome = nome;
    }

    abstract public Double calcularMedia();

    @Override
    public String toString() {
        return "\nInformações aluno:" +
                "\nRA: " + ra +
                "\nNome: " + nome;
    }

    public Integer getRa() {
        return ra;
    }
}
