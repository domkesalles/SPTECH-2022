public class TesteAluno {
    public static void main(String[] args) {

        Aluno aluno1 = new AlunoFundamental(1, "Felipe", 6.0, 8.0, 3.7, 4.7);
        Aluno aluno2 = new AlunoGraduacao(2, "Leonardo", 7.0, 4.0);
        Aluno aluno3 = new AlunoPos(3, "Fernando", 8.0, 9.0, 3.5);
        Escola escola = new Escola("São Paulo Tech School");

        System.out.println(aluno1);
        System.out.println(aluno2);
        System.out.println(aluno3);

        escola.adicionarAluno(aluno1);
        escola.adicionarAluno(aluno2);
        escola.adicionarAluno(aluno3);

        escola.exibeTodos();
        escola.exibeAlunoGraduacao();
        escola.exibeAprovados();

        escola.buscarAluno(1);
        escola.buscarAluno(7);
    }
}
